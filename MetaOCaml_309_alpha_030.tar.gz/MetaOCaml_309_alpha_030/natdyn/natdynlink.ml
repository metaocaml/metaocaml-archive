type natdynmod

type t =
    Handle of natdynmod
  | Toplevel_exn of (natdynmod * exn)

type error =
    Link_error of string
  | Init_entry_not_found of string
  | Caml_entry_not_found of string
  | Fini_entry_not_found of string

external ml_load : bool -> string -> string -> t = "ml_natdynload"

exception Error of error

let _ =
  Callback.register_exception "Natdynlink.Error" (Error (Link_error ""))

let loadfile name entry =
  match ml_load false name entry with
    Handle h -> h
  | Toplevel_exn (h, e) -> raise e

let loadfile_private name entry =
  match ml_load true name entry with
    Handle h -> h
  | Toplevel_exn (h, e) -> raise e

let error_message = function
    Link_error s -> "Link error " ^ s
  | Init_entry_not_found s -> "Symbol not found " ^ s
  | Caml_entry_not_found s -> "Symbol not found " ^ s
  | Fini_entry_not_found s -> "Symbol not found " ^ s
