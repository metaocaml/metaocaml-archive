(* $Id: dl.ml,v 1.1 2005/03/25 23:56:19 kswadi Exp $
 *
 *)

(* Interface to libdl.so *)

type library
type symbol = int

external dl_open : string -> library = "dl_open"
external dl_sym : library -> string -> symbol = "dl_sym"
external dl_close : library -> unit = "dl_close"
external dl_dummy_library : unit -> library = "dl_dummy_library"

external call1 : symbol -> 'a -> 'z
  = "dl_call1"
external call2 : symbol -> 'a -> 'b -> 'z
  = "dl_call2"
external call3 : symbol -> 'a -> 'b -> 'c -> 'z
  = "dl_call3"
external call4 : symbol -> 'a -> 'b -> 'c -> 'd -> 'z
  = "dl_call4"
external call5 : symbol -> 'a -> 'b -> 'c -> 'd -> 'e -> 'z
  = "dl_call5_bytecode" "dl_call5"
external call6 : symbol -> 'a -> 'b -> 'c -> 'd -> 'e -> 'f -> 'z
  = "dl_call6_bytecode" "dl_call6"
external call7 : symbol -> 'a -> 'b -> 'c -> 'd -> 'e -> 'f -> 'g -> 'z
  = "dl_call7_bytecode" "dl_call7"
external call8 : symbol -> 'a -> 'b -> 'c -> 'd -> 'e -> 'f -> 'g -> 'h -> 'z
  = "dl_call8_bytecode" "dl_call8"
external call9 : symbol -> 'a -> 'b -> 'c -> 'd -> 'e -> 'f -> 'g -> 'h -> 'i -> 'z
  = "dl_call9_bytecode" "dl_call9"
external call10 : symbol -> 'a -> 'b -> 'c -> 'd -> 'e -> 'f -> 'g -> 'h -> 'i -> 'j -> 'z
  = "dl_call10_bytecode" "dl_call10"

(*======================================================================*)

external call_all : symbol -> 'a -> 'z
  = "dl_call_all"

(* F90 entry points.  *)
external f90call_i : symbol -> 'a -> 'z
  = "dl_f90call_i"
external f90call_array_i : symbol -> 'a -> 'z
  = "dl_f90call_array_i"
external f90call_array_f : symbol -> 'a -> 'z
  = "dl_f90call_array_f"
external f90call_array_c_c : symbol -> 'a -> 'z
  = "dl_f90call_array_c_c"
external f90call_array_f_f : symbol -> 'a -> 'z
  = "dl_f90call_array_f_f"

