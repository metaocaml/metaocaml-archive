
Trx.init_times()

let n = 100

let xx = Array.create n 6
let yy = Array.create n 7

let rec iproc n x y = 
   if n > 0 then
             x.(n-1) * y.(n-1) + (iproc (n-1) x y)
            else 0
(* only 2 level *)
let rec iproc' n x y =
   if n > 0 
      then .< ( x.(n-1) * ((.~y).(n-1)) + .~(iproc' (n-1) x y)) >.
      else .<0>.

let unstage =
    Trx.time 100000 "unstaged running"
         (fun () -> iproc n xx yy)

let st1Run =
    Trx.time 1000 "stage 1 running"
         (fun () -> .< (fun y -> .~(iproc' n xx .<y>.))>.) 
let comp =
    Trx.time 100 "compiling"
         (fun () -> (.! st1Run)  )
let st2Run =
    Trx.time 100000 "stage 2 running"
         (fun () -> comp yy)

let _ = Trx.print_times()
