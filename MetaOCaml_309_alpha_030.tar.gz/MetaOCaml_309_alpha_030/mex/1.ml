
(* Author:  Walid Taha
   Date:    Fri Aug 31 03:03:11 EDT 2001 *)

(* In MetaML we used to write this as 

	run <~<42>> 

   In Scheme

        (eval `,`42) *)

.! .< .~ .< 42>. >. ;;


