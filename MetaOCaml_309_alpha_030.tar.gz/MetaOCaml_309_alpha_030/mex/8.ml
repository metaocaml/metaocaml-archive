
(* Title:   Inner product
   Author:  Walid Taha
   Date:    Sun Oct 21 16:23:31 EDT 2001 
   Comment: It would be interesting to compare to int matrices *)

Trx.init_times ()

let n = 10;;

let a = Array.create n 0.0;;

let b = Array.create n 0.0;;

for i = 0 to n-1 do
    a.(i) <- float ((i mod 7 + i * 3) mod 97);
    b.(i) <- float ((((n-3*i-1) mod 4) + i * 2) mod 95)
   done;;

let dot x y = 
 let res = ref 0.0 in
  (for i = 0 to n-1 do
    res := (x.(i)*.y.(i) +. !res)
   done;
   !res);;

let lift x = .<x>.;;

let dot2 x y = 
 let res = ref .<0.0>. in
  (for i = 0 to n-1 do
    res := .<.~(lift x.(i))*.y.(i) +. .~(!res)>.
   done;
   !res);;

(* Timing Experiment #use "mex/8.ml";; *)

let unstagedRunning = 
     Trx.time 100000
        "unstaged running"
        (fun () -> dot a b)

let stage1 = 
     Trx.time 100000
        "stage 1"
        (fun () -> dot2 a b)

let compilation = 
     Trx.time 10
        "compilation"
        (fun () -> .! .<fun () -> .~stage1>.)

let stage2 = 
     Trx.time 100000
        "stage 2 (running)"
        (fun () -> compilation ())

let _ = Trx.print_times ()



