(* A collection of tests for C offshoring *)

let numtests = ref 0;;
let failed = ref 0;;
let passed = ref 0;;

let outp (b:bool) = 
   incr numtests;
   if b then
  (incr passed;
    Printf.printf "OK %d\n" !numtests;
    flush stdout)
  else
    (incr failed;
    Printf.printf "ERROR %d.\n" !numtests;
    flush stdout;
    exit 0);;
(* -------------------------------------------- *)

(* Arithmetic operators.  *)
let a = .<(1 + 1) + 1>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<((3 + 5) - 1) * (6 / 2)>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<24 mod 5>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* Max and min operators.  *)
let a = .<min 3 10>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<max 3 10>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<min (22 / 11) (9 * 3)>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<max (max 3 4) 5>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* Bitwise shifts.  *)
let a = .<0x1f asr 2>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<0x23c lsr 8>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<1 lsl 4>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* Bitwise operators.  *)
let a = .<0xfffe land 0xf>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<0xe lor 1>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<0x3 lxor 1>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<(0x3 lxor 1) lxor 1>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* If-then-else (and relational operators).  *)
let a = .<if 5 < 6 then 55 else 66>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<if 2=2 then 22 else 0>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<9 * (if 0 >= 6 then 3 else 1)>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<1 + (if 6 >= 0 then (if 1=2 then 5 else 10) else (38))>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let z = (if 5 < 6 then 55 else 66) in z>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* Casts.  *)
let a = .<if (5.0 +. (float_of_int 3)) < 9.0 then 10 else 11>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<2 + (int_of_float)4.5>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* Unary minus.  *)
let a = .<int_of_float (5.0 +. -. .~(.<0.0>.))>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<- .~(.<0>.)>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* Pred/succ. *)
let a = .<let a = 1 in (5 + (succ a))>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let a = 9 in (5 + (pred a))>. in let b = ((.! a) == (.!{C} a)) in outp b;;


(* Various integer tests  *)

let a = .<let a = 4 in 5 + a>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let a = 4*2 in
             let b = 10 in
              a + b >. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let a = 6/2 in
             let b = 10 in
             let c = 1 in
             a + b - c >. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a =  .<let (z_1232289) = 1 in
              let (z_1232290) = 1 in
              let (z_1232291) = ((z_1232289) + (z_1232290)) in
              ((z_1232291) + (z_1232289))>.  in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let b = 8 in
               if b < 5 then
                  b + 10
               else
                  b lsl 2>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* Function tests *)

let a = .<let f a = a * 3 in f 8>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let f a = a * 3 in (f 8) + (f 2)>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let f a = a * 3 in (let b = 3 in b+(f 2))>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let rec rf n = if n = 0 then 1 else (1+rf (n-1)) in rf 5>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let f (a,b) = a + b in f (10,12)>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let f (a,b,c) = max a (max b c) + 0 in f (5,3,1) >. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let f (a,fx) = if fx>0.0 then a+1 else a+10 in f (4,12.0)>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let f a = a + 1 in
             let g b = f b in
             g 6>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let f a = a + 1 in
             let g b = f b in
             let h (x,y,z) = (f x) * (g y) - z in
             h (2, 3, 4)>. in let b = ((.! a) == (.!{C} a)) in outp b;;


(* The power function.  *)

let a = .<
  let even n = (n mod 2) = 0 in
  let square x = x*x in
  let rec power (n, x) =
    if n=0 then 1
    else if even n then square (power ((n/2), x))
         else x*(power ((n-1), x)) in
  power(5,2)>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* References *)

let a = .<let ar = ref 10 in !ar>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let ar = 10 in let foo arg = ar + arg+ 5 in foo 1>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let ar = ref 10 in let foo arg = !ar + arg * 9 in foo 2>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let a = ref 0 in for i=1 to 10 do a:=!a+5 done; !a>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let ar = ref 10 in ar := !ar + 1; ar := !ar * 3; !ar>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let x = ref 32 in x := !(x)+10; !x>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .< let x = 17 in
   let y = ref 18 in
   let z = 24 in
   y:=(!y)+z; y := (!y)/2; y:=(!y)+21; !y
>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* Match *)

let a = .<let rv = ref 5 in 
             let sel = 123 in
              (match sel with
                 123 -> rv := !rv + 20; rv := !rv - 1
               | 567 -> rv := !rv * 3
               | _ -> rv := 0);
             !rv>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let a = 10 in
             let b = a / 2 in
             let ret = ref 0 in
             ret := !ret + 4;
             let foo (i,j,k) =
               (match i with
                   0 -> ret := a+j
                 | 1 -> ret := b+k
                 | _ -> ret := j+k); !ret
             in foo (3,4,5)>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let sum = ref 0 in for i = 1 to 8 do sum:=!sum+1 done; !sum>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let r = ref 32 in for i = 10 downto 2 do (let a = 6 in r:=i+a) done; !r>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let ri = ref 1 in let j = 10 in let ret = ref 0 in while !ri < j do  ret := !ri; ri:=!ri+2 done; !ret>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let ret = ref 0 in while 0 = 1 do (while 2 = 3 do (while 4 = 5 do ret:=!ret+1  done) done) done; !ret>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let r = ref 0 in 
             let g (x,y) = r:=!r+(x+y); !r in
             while g (1,2) <= 0 do g (2,3) done; !r>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* Incr/decr.  *) 
let a = .<let r = ref 10 in incr r; incr r; !r>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let r = ref 80 in decr r; decr r; !r>. in let b = ((.! a) == (.!{C} a)) in outp b;;


(* --- Dot product. ---  *)
let a = .<
let n = 10 in
let a = Array.make 10 0.0 in
let b = Array.make 10 0.0 in
  for i = 0 to n-1 do
      a.(i) <- float ((i mod 7 + i * 3) mod 97);
      b.(i) <- float ((((n-3*i-1) mod 4) + i * 2) mod 95)
  done;
let dot nnn = 
 let res = ref 0.0 in
  (for i = 0 to nnn-1 do
    res := (a.(i) *. b.(i) +. !res)
   done;
   !res)
 in int_of_float ((dot 10) /. 10.0) 
>. in let b = ((.! a) == (.!{C} a)) in outp b;;


(* --- Chebyshev approximation.  Adapted from mex/chebychev.ml for
       Ocaml->C subset. --- *)
let a = .<
let func x = x *. x in
let approx (n, xa, xb) =
let k  = ref 0 in 
let j  = ref 0 in
let xm = ref 0.0 in
let xp = ref  0.0 in
let sm = ref 0.0 in
let c  = Array.make 10 0.0 in
let f  = Array.make (11) 0.0 in
let pi = 3.14 in
 begin
  xp := (xb+.xa)/. 2.0;
  xm := (xb-.xa)/. 2.0;
  for k = 1 to n do
    f.(k) <- func(!xp +. !xm*.cos(pi*.((float k)-.0.5)/.2.0))
  done;

  for j = 0 to (n-1) do
    sm := 0.0;
    for k = 1 to n do
      sm := !sm +. f.(k)*.cos(pi*.(float j)*.((float k)-.0.5)/. (float n))
    done;
    c.(j) <- (2.0/.(float n))*. !sm
  done;

  (* Compute let a =sum (for comparing translator answer to Ocaml answer). *)
  let checksum = ref 0.0 in
  for cs = 0 to (n-1) do
    checksum := !checksum +. c.(cs) 
  done;
 (int_of_float (!checksum *. 100.0)) mod 255
 end
in approx (10, 1.0, 2.0)
>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* --- Matrix multiply --- *)
let a = .<
let nn = 3 in
let aa = Array.make_matrix 3 3 0.0 in
let bb = Array.make_matrix 3 3 0.0 in
let cc = Array.make_matrix 3 3 0.0 in
  for i = 0 to (nn-1) do
    for j = 0 to (nn-1) do
      aa.(i).(j) <- 3.0;
      bb.(i).(j) <- 2.0;
      cc.(i).(j) <- 0.0;
    done;
  done;

let matmul (n) =
  let sum = ref 0.0 in
  for i = 0 to (n-1) do
    for j = 0 to (n-1) do
      sum := 0.0;
      for k = 0 to (n-1) do
        sum := !sum +. aa.(i).(k) *. bb.(k).(j)
      done;
      cc.(i).(j) <- !sum;
    done;
  done;

  (* Compute a checksum.  *)
  let checksum = ref 0 in
  for i = 0 to (n-1) do
    for j = 0 to (n-1) do
      checksum := !checksum + (int_of_float cc.(i).(j))
    done;
  done;
  !checksum
  in matmul (3)
>. in let b = ((.! a) == (.!{C} a)) in
   outp b;;


(* Various *)

let a = .<let x = ref 5 in 
        if !x < 4 then
          x := !x * 3
        else    
          x := !x + 1;
        !x>. in let b = ((.! a) == (.!{C} a)) in outp b;; 

let a = .<let x = ref 3 in 
        let a = 21 in
        if !x < 4 then
          begin
          x := !x * 3;
          x := !x + 1
          end
        else    
          x := !x + 1;
          x := !x + 3;
        a+(!x)>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let verdad (a,b) = 
          let s = ref 0.0 in
          if a <= b then
            begin
            for i=a to b do
              if i < 3 then
                s := !s +. 5.0
              else
                s := !s +. 2.0
            done
            end
          else 
            begin
            for i=b downto a do
              if i > 3 then
                s := !s +. 1.0 
              else
                s := !s +. 3.0
            done
           end;
           int_of_float !s
         in verdad (2, 5)>. in let b = ((.! a) == (.!{C} a)) in outp b;;


(* Arithmetic operators.  *)

(* int tests *)

  (* base *)
let c = .<fun (x,y) -> x + y>. in 
outp (((.!{C} c) (3,4)) == ((.! c) (3,4)));;
Trx.OffshoreC.closeCurrentLib();;

  (* one-dim array *)
let x = Array.make 2 2 in  
let c = .<fun (x: int array) -> x.(0) +  x.(0)>. in
outp (((.!{C} c) x) == ((.! c) x)) ;;
Trx.OffshoreC.closeCurrentLib();;

let x = Array.make 2 2 in  
let c =  (.<fun ((x: int array),z) -> x.(0) +  x.(0) + z>.) in 
outp (((.!{C} c) (x,2)) == ((.! c) (x,2)));;
Trx.OffshoreC.closeCurrentLib();;

  (* one-dim array *)

let x1 = Array.make 2 2 in  
let y1 = Array.make 2 2 in
let c1 = .<fun (x1,y1) -> x1.(0) +  y1.(0)>. in 
let a1 = ((.!{Trx.run_gcc} c1) (x1,y1)) in 
let b1 = ((.!  c1) (x1,y1)) in
outp (a1 == b1);;
Trx.OffshoreC.closeCurrentLib();;

(* two-dim array *)
let x = Array.make_matrix 2 2 2 in  
let c = .<fun (x: int array array) -> x.(0).(0) +  x.(0).(0)>. in 
outp (((.!{C} c ) x) == ((.! c ) x));;
Trx.OffshoreC.closeCurrentLib();;

let x = Array.make_matrix 2 2 2 in  
let y = Array.make_matrix 2 2 2 in 
let c = .<fun (x,y) -> x.(0).(0) +  y.(0).(0)>. in 
let a = ((.!{C} c ) (x,y)) in 
let b =   ((.! c ) (x,y)) in 
outp (a == b);;
Trx.OffshoreC.closeCurrentLib();;

let x = Array.make_matrix 2 2 2 in  
let y = Array.make_matrix 2 2 2 in 
let c = .<fun (x,y,z) -> x.(0).(0) +  y.(0).(0) + z>. in 
let a = ((.!{C} c ) (x,y,4)) in 
let b =   ((.! c ) (x,y,4)) in 
outp (a == b);;
Trx.OffshoreC.closeCurrentLib();;

(* doubles tests *)


 (* one-dim array *)
let x = Array.make 2 2.0 in  
let c = .<fun (x: float array) -> x.(0) <- x.(0) +.  x.(0) ; 4>.in  
outp (((.!{C} c) x) == ((.! c ) x));;
Trx.OffshoreC.closeCurrentLib();;

let x = Array.make 200 33.3 in  
let c = .<fun (x: float array) -> x.(0) <- x.(0) +.  x.(0) ; 4>.in  
outp (((.!{C} c) x) == ((.! c ) x) );;
Trx.OffshoreC.closeCurrentLib();;

let x = Array.make 2 2.0 in  
let c = .<fun ((x: float array), z) -> x.(0) <- x.(0) +.  x.(0)+. z ; 4>.in  
outp (((.!{C} c) (x, 3.0)) == ((.! c ) (x, 3.0)) );;
Trx.OffshoreC.closeCurrentLib();;

 (* one-dim array *)
let x = Array.make 2 2.0 in  
let y = Array.make 2 2.0 in
let c =  .<fun (x,y) -> x.(0) +. y.(0) ; 4>. in 
outp (((.!{C} c) (x,y)) == ((.! c) (x,y)));;
Trx.OffshoreC.closeCurrentLib();;

 (* two-dim array *)
let x = Array.make_matrix 2 2 2.0 in  
let c = .<fun (x: float array array) -> 
  x.(0).(0) +.  x.(0).(0); 4>. in 
outp (((.!{C} c) x) == ((.! c) x));;
Trx.OffshoreC.closeCurrentLib();;

let x = Array.make_matrix 2 2 2.0 in  
let y = Array.make_matrix 2 2 2.0 in  
let c = .<fun (x,y) -> x.(0).(0) +.  y.(0).(0); 4>. in 
outp (((.!{C} c ) (x,y)) == ((.! c ) (x,y)));;
Trx.OffshoreC.closeCurrentLib();;

let x = Array.make_matrix 2 2 2.0 in  
let y = Array.make_matrix 2 2 2.0 in  
let c = .<fun (x,y,z) -> x.(0).(0) +.  y.(0).(0) +. z; 4>. in 
outp (((.!{C} c ) (x,y,3.0)) == ((.! c ) (x,y,3.0)));;
Trx.OffshoreC.closeCurrentLib();;

(* Array initialization *)
let a = .<let x = Array.make 4 2 in x.(0)>. in let b = ((.! a) == (.!{C} a)) in outp b;;

let a = .<let x = Array.make_matrix 4 3 2 in x.(3).(2)>. in let b = ((.! a) == (.!{C} a)) in outp b;;

(* Declarations before returning lambdas *)
let a = .<let a = 1 in let f x =  x + a in f 4>. in let b = ((.! a) == (.!{C} a)) in outp b;; 
let a = .<let a = 1 in fun x -> let b = 5 in x + a + b>. in let b = (((.! a) 2) == ((.!{C} a) 2)) in outp b;;
Trx.OffshoreC.closeCurrentLib();; 
let a = .<let a = 1 in let f x = let b = 5 in x + a + b in f 4>. in let b = ((.! a) == (.!{C} a)) in outp b;;
let a = .<let b = 1 in fun x -> x + b>. in let b = (((.! a) 2) == ((.!{C} a) 2)) in outp b;;


let fib_31 = .<((1 + 1) + 1)>. ;;

let fib_32 =
  .<let (z_1232289) = 1 in
  let (z_1232290) = 1 in
  let (z_1232291) = ((z_1232289) + (z_1232290)) in
  ((z_1232291) + (z_1232289))>. ;;

let knapsack_31 =
  .<fun vl_576826 ->
    (max
       ((vl_576826 3) +
          (max ((vl_576826 2) + (max ((vl_576826 1) + 0) 0))
             (max ((vl_576826 1) + 0) 0)))
       (max ((vl_576826 2) + (max ((vl_576826 1) + 0) 0))
          (max ((vl_576826 1) + 0) 0)))>.
    
let knapsack_32 =
  .<fun vl_609594 ->
    let (z_609595) = 0 in
    let (z_609596) = 0 in
    let (z_609597) = (max ((vl_609594 1) + (z_609595)) (z_609596)) in
    let (z_609598) = 0 in
    let (z_609599) = 0 in
    let (z_609600) = (max ((vl_609594 1) + (z_609598)) (z_609599)) in
    let (z_609601) = (max ((vl_609594 2) + (z_609597)) (z_609600)) in
    let (z_609602) = 0 in
    let (z_609603) = (max ((vl_609594 1) + (z_609599)) (z_609602)) in
    let (z_609604) = 0 in
    let (z_609605) = 0 in
    let (z_609606) = (max ((vl_609594 1) + (z_609604)) (z_609605)) in
    let (z_609607) = (max ((vl_609594 2) + (z_609603)) (z_609606)) in
    (max ((vl_609594 3) + (z_609601)) (z_609607))>.

let lcs_4 =
  .<fun ((a_1232314), (b_1232315)) ->
   if (((a_1232314) 2) = ((b_1232315) 2)) then
    ((if (((a_1232314) 1) = ((b_1232315) 1)) then (0 + 1) else (max 0 0)) +
     1)
   else
    (max
     (if (((a_1232314) 2) = ((b_1232315) 1)) then (0 + 1)
      else
       (max 0
        (if (((a_1232314) 1) = ((b_1232315) 1)) then (0 + 1) else (max 0 0))))
     (if (((a_1232314) 1) = ((b_1232315) 2)) then (0 + 1)
      else
       (max
        (if (((a_1232314) 1) = ((b_1232315) 1)) then (0 + 1) else (max 0 0))
        0)))>.;;

let mult_3 =  
  .<fun (f_118786) ->
    let (z_118787) = 0 in
    let (z_118788) = 0 in
    let (z_118789) =
      (((z_118787) + (z_118788)) +
         ((((f_118786) (1 - 1)) * ((f_118786) 1)) * ((f_118786) 2))) in
    let (z_118790) = 0 in
    let (z_118791) =
      (((z_118788) + (z_118790)) +
         ((((f_118786) (2 - 1)) * ((f_118786) 2)) * ((f_118786) 3))) in
    let (z_118792) =
      (min
         (((z_118787) + (z_118791)) +
            ((((f_118786) (1 - 1)) * ((f_118786) 1)) * ((f_118786) 3)))
         (((z_118789) + (z_118790)) +
            ((((f_118786) (1 - 1)) * ((f_118786) 2)) * ((f_118786) 3)))) in
    let (z_118793) = 0 in
    let (z_118794) =
      (((z_118790) + (z_118793)) +
         ((((f_118786) (3 - 1)) * ((f_118786) 3)) * ((f_118786) 4))) in
    let (z_118795) =
      (min
         (((z_118788) + (z_118794)) +
            ((((f_118786) (2 - 1)) * ((f_118786) 2)) * ((f_118786) 4)))
         (((z_118791) + (z_118793)) +
            ((((f_118786) (2 - 1)) * ((f_118786) 3)) * ((f_118786) 4)))) in
    (min
       (((z_118787) + (z_118795)) +
          ((((f_118786) (1 - 1)) * ((f_118786) 1)) * ((f_118786) 4)))
       (((z_118789) + (z_118794)) +
          ((((f_118786) (1 - 1)) * ((f_118786) 2)) * ((f_118786) 4))))>.;;

let lcs_21 =
  .<fun ((a_904506), (b_904507)) ->
    let (z_904508) = 0 in
    let (z_904509) = 0 in
    let (z_904510) = 0 in
    let (z_904511) =
      if (((a_904506) 1) = ((b_904507) 1)) then ((z_904508) + 1)
      else (max (z_904509) (z_904510)) in
    let (z_904512) = 0 in
    let (z_904513) =
      if (((a_904506) 2) = ((b_904507) 1)) then ((z_904509) + 1)
      else (max (z_904512) (z_904511)) in
    let (z_904514) = 0 in
    let (z_904515) =
      if (((a_904506) 1) = ((b_904507) 2)) then ((z_904510) + 1)
      else (max (z_904511) (z_904514)) in
    if (((a_904506) 2) = ((b_904507) 2)) then ((z_904511) + 1)
    else (max (z_904513) (z_904515))>.;;

let lcs_22 =
  .<fun ((a_838970), (b_838971)) ->
    if (((a_838970) 2) = ((b_838971) 2)) then
      ((if (((a_838970) 1) = ((b_838971) 1)) then (0 + 1) else (max 0 0)) + 1)
    else
      (max
         (if (((a_838970) 2) = ((b_838971) 1)) then (0 + 1)
         else
           (max 0
              (if (((a_838970) 1) = ((b_838971) 1)) then (0 + 1) else (max 0 0))))
         (if (((a_838970) 1) = ((b_838971) 2)) then (0 + 1)
         else
           (max
              (if (((a_838970) 1) = ((b_838971) 1)) then (0 + 1) else (max 0 0)) 0)))>.;;
      
let lcs_3 = 
  .<fun ((a_319542), (b_319543)) ->
    let (z_319544) = 0 in
    let (z_319545) = 0 in
    let (z_319546) = 0 in
    let (z_319547) =
      if (((a_319542) 1) = ((b_319543) 1)) then ((z_319544) + 1)
      else (max (z_319545) (z_319546)) in
    let (z_319548) = 0 in
    let (z_319549) =
      if (((a_319542) 2) = ((b_319543) 1)) then ((z_319545) + 1)
      else (max (z_319548) (z_319547)) in
    let (z_319550) = 0 in
    let (z_319551) =
      if (((a_319542) 1) = ((b_319543) 2)) then ((z_319546) + 1)
      else (max (z_319547) (z_319550)) in
    let (z_319552) =
      if (((a_319542) 2) = ((b_319543) 2)) then ((z_319547) + 1)
      else (max (z_319549) (z_319551)) in
    let (z_319553) = 0 in
    let (z_319554) =
      if (((a_319542) 3) = ((b_319543) 1)) then ((z_319548) + 1)
      else (max (z_319553) (z_319549)) in
    let (z_319555) =
      if (((a_319542) 3) = ((b_319543) 2)) then ((z_319549) + 1)
      else (max (z_319554) (z_319552)) in
    let (z_319556) = 0 in
    let (z_319557) =
      if (((a_319542) 1) = ((b_319543) 3)) then ((z_319550) + 1)
      else (max (z_319551) (z_319556)) in
    let (z_319558) =
      if (((a_319542) 2) = ((b_319543) 3)) then ((z_319551) + 1)
      else (max (z_319552) (z_319557)) in
    if (((a_319542) 3) = ((b_319543) 3)) then ((z_319552) + 1)
    else (max (z_319555) (z_319558))>.;;

Printf.printf "# tests passed: %d\n" !passed;;
Printf.printf "# tests failed: %d\n" !failed;;
if (!numtests <> (!passed + !failed)) then
  begin
  Printf.printf "Error: %d tests were not executed!\n" 
   (!numtests - (!passed + !failed))
  end
;;
