
(* Author:  Walid Taha
   Date:    Thu Oct 25 16:32:25 EDT 2001 *)

Time_util.init_times ()     (* Initialize a timer library *)


(* Chebyshev approximation, from paper by Robert Glueck et al. *)

let approx n xa xb func =
let k  = ref 0
and j  = ref 0
and xm = ref 0.0
and xp = ref  0.0
and sm = ref 0.0
and c  = Array.create n 0.0
and f  = Array.create (n+1) 0.0
and pi = 3.14
in 
 begin
  xp := (xb+.xa)/. 2.0;
  xm := (xb-.xa)/. 2.0;
  for k = 1 to n do
    f.(k) <- func(!xp+. !xm*.cos(pi*.((float k)-.0.5)/.2.0))
  done;

  for j = 0 to (n-1) do
    sm := 0.0;
    for k = 1 to n do
      sm := !sm +. f.(k)*.cos(pi*.(float j)*.((float k)-.0.5)/. (float n))
    done;
    c.(j) <- (2.0/.(float n))*. !sm
  done;
 c
 end;;

let unstagedRunning = 
  Time_util.timenew "unstaged running"(fun () -> approx 10 1.0 2.0 (fun x -> x*.x));;

let _ = Time_util.print_times ()
