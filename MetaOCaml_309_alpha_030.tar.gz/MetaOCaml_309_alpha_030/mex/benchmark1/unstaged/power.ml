
(* Author:  Walid Taha
   Date:    Fri Sep 14 18:48:32 GMT 2001 *)

Time_util.init_times ()     (* Initialize a timer library *)


(* A single-stage version of the power function *)

let even n = (n mod 2) = 0

let square x = x*x

let rec power n x = 
  if n=0 then 1
   else if even n then square (power (n/2) x)
	 else x*(power (n-1) x)

let unstagedRunning = 
  Time_util.timenew "unstaged running"(fun () -> power  50000 1)

let baseline = Time_util.timenew "baseline" (fun () -> ())

(* Print all the timings *)

let _ = Time_util.print_times ()
