
Time_util.init_times()

let n = 100

let xx = Array.create n 6
let yy = Array.create n 7

let rec iproc n x y = 
   if n > 0 then
             x.(n-1) * y.(n-1) + (iproc (n-1) x y)
            else 0

let unstage =
    Time_util.timenew "unstaged running"
         (fun () -> iproc n xx yy)

let _ = Time_util.print_times()
