
(* Author:  Walid Taha
   Date:    Fri Sep 14 18:48:32 GMT 2001 *)

Trx.init_times ()     (* Initialize a timer library *)


(* A single-stage version of the power function *)

let even n = (n mod 2) = 0

let square x = x*x

let rec power n x = 
  if n=0 then 1
   else if even n then square (power (n/2) x)
	 else x*(power (n-1) x)

(* A two-stage version of the power function *)

let rec power' n x = 
  if n=0 then .<1>.
   else if even n then .<square .~(power' (n/2) x)>.
	 else .<.~x* .~(power' (n-1) x)>.
let unstagedRunning = 
  Trx.timenew "unstaged running"(fun () -> power  50000 1)

let stage1Running =
  Trx.timenew "stage 1 running" (fun () -> .<fun x-> .~(power' 50000 .<x>.)>.)

let compiling = Trx.timenew "compiling"
                  (fun () -> .! stage1Running)

let stage2Running = Trx.timenew "stage 2 running" (fun () -> (compiling 1))

let baseline = Trx.timenew "baseline" (fun () -> ())

(* Print all the timings *)

let _ = Trx.print_times ()
