
(* Author:  Cristiano Calcagno
   Date:    Fri Aug 31 03:03:11 EDT 2001 *)

let a = .<for i = 1 to 10000000 do (fun _ -> ()) i done>.

let r = .!a; 42
