(* Author:  Cristiano Calcagno
   Date:    Fri Aug 31 03:03:11 EDT 2001 *)



type t = A of int | B of r
and  r = { contents : 'b. ('b,t) code }

let rec runall = function
 | A i -> i
 | B c -> runall (.! (c.contents))



let a = B {contents = .< A 45 >. }
let b = B {contents = .< a >.    }
let c = B {contents = .< b >.    }
let res1 = [ runall a; runall b; runall c ]

let a1 = B {contents = .< B { contents = .< A 26 >. } >. }

type rr =  { ra : 'a. rr -> (('a,t) code)  -> int} 

let  myrun rrec = function
  | A i -> i
  | B c -> (rrec.ra) rrec (c.contents) 


let res2 = runall a1

(* evaluating runall a1 causes a type error at runtime:
Characters 44-48:
  This expression has type ('a, t) code but is here used with type ('b, t) code

Exception: Trx.TypeCheckingError.
*)

type 'a t2 = C of int
  | D of ('a, 'a t2) code


let rec runt2  = function 
  | C i -> i
  | D c -> runt2 (.! c) 

