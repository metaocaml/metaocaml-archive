Trx.init_times () (* Initialize a timer library *)

(* Single stage version of innerproduct function *)

let rec inner a b =  match a with
        |[] -> 0
        |hd :: tl -> match b with
                      | [] -> 0
                      | hdb :: tlb -> hd*hdb + inner tl tlb
let rec lis n z = match n with
                   | 0 -> []
                   | n -> z :: lis (n - 1) z
let x = lis 100 3
let y = lis 100 4
let unstagedRunning =
    Trx.time 10000 "unstaged running"(fun () -> inner x y)

let rec inner' a b =
         match a with
          |[] -> .<0>.
          |hd :: tl -> match b with
                        |[] -> .<0>.
                        | hdb:: tlb -> .<(hd * .~hdb) +
                                              .~(inner' tl tlb)>.
let rec upper z =
      match z with
      |[] -> []
      | hd :: tl -> .<hd>. :: upper tl

let gen n = if n > 0 then 4 else 0

let rec mklist n f =
    match n with
    | 0 -> []
    | n -> .< .~f n>. :: (mklist (n-1) f)

let stage1Running =
    Trx.time 100 "stage 1 running"
             (fun () -> .<fun g -> .~(inner' x (mklist 100 .<g>.))>.)
let compiling = Trx.time 10 "compiling" (fun () -> .! stage1Running)

let stage2Running = Trx.time 10000 "stage 2 running" (fun () -> (compiling gen))

let baseline = Trx.time 100000 "baseline" (fun () -> ())

let _ = Trx.print_times ()

