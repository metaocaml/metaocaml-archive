#!/bin/sh

topdir=`dirname $0`

exec $topdir/boot/ocamlrun $topdir/boot/ocamlc -nostdlib -I $topdir/stdlib "$@"
